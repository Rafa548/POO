
public interface Comprador {
	public int pagar(Caixa cx);
}
