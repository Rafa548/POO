
public class Aluno {

}
