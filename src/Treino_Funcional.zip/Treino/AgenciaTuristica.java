package Treino;

import java.util.ArrayList;
import java.util.TreeSet;

public class AgenciaTuristica implements Random{
    private String local;
    private String nome;
    private ArrayList<ArrayList<String>> l_1 = new ArrayList<ArrayList<String>>();
    private TreeSet<String> l_2 = new TreeSet<String>();

    public AgenciaTuristica(String nome, String local) {
        this.nome = nome;
        this.local = local;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public void add(Atividade a){
        ArrayList<String> l_2 = new ArrayList<String>();
        ArrayList<String> l_3 = new ArrayList<String>();
        l_2.add("num=" + a.getId());
        l_2.add("nome=" + a.getNome());
        l_3.add("Atividade " + l_2);
        l_1.add(l_3);

    }

    public void add_2(String x){
        l_2.add(x);      
    }

    public TreeSet<String> getAllItems(){
        return l_2;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((l_1 == null) ? 0 : l_1.hashCode());
        result = prime * result + ((l_2 == null) ? 0 : l_2.hashCode());
        result = prime * result + ((local == null) ? 0 : local.hashCode());
        result = prime * result + ((nome == null) ? 0 : nome.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AgenciaTuristica other = (AgenciaTuristica) obj;
        if (l_1 == null) {
            if (other.l_1 != null)
                return false;
        } else if (!l_1.equals(other.l_1))
            return false;
        if (l_2 == null) {
            if (other.l_2 != null)
                return false;
        } else if (!l_2.equals(other.l_2))
            return false;
        if (local == null) {
            if (other.local != null)
                return false;
        } else if (!local.equals(other.local))
            return false;
        if (nome == null) {
            if (other.nome != null)
                return false;
        } else if (!nome.equals(other.nome))
            return false;
        return true;
    }

    public int totalItems() {
		return rrr.size();
	}
    
    public String toString() {
        return "AGENCIA: " + nome + "\n" + l_1;
    }

    public ArrayList<ArrayList<String>> atividades() {
        return l_1;
    }
}
