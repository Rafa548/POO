package Treino;

public enum TipoComida {
    CHURRASQUEIRA, VEGETARIANO, MARISQUEIRA, ITALIANO
}
