package Treino;

import java.util.ArrayList;
import java.util.List;

public class Gastronomia extends Atividade implements Random{

    private ArrayList<ArrayList<String>> l_1 = new ArrayList<ArrayList<String>>();
    private List<Restaurante> lista;


    public Gastronomia(int id, String name) {
        super(id, name);
    }

    public Gastronomia(int id, String name, List<Restaurante> lista) {
        super(id, name);
        this.lista = lista;
    }

    public ArrayList<ArrayList<String>> getLista() {
        return l_1;
    }

    public int totalRestaurantes() {
        for (Restaurante r : lista){
            rrr.add("idc" + r.getNome());
        }
        return lista.size();
    }

    public void add(Restaurante r) {
        ArrayList<String> l_2 = new ArrayList<String>();
        ArrayList<String> l_3 = new ArrayList<String>();
        l_2.add("nome=" + r.getNome());
        l_2.add("tipo=" + r.getTipoComida());
        l_3.add("Restaurante " + l_2);
        l_1.add(l_3);
        rrr.add("idc" + l_3);
    }

    public ArrayList<ArrayList<String>> locais(){
        return l_1;
    }
    
}
