package Treino;

import java.util.ArrayList;

public class PasseioBicicleta extends Atividade implements Random{
    private String[] s_list;
    private ArrayList<String> locals = new ArrayList<String>();

    public PasseioBicicleta(int id, String name, String[] s_list) {
        super(id, name);
        this.s_list = s_list;
    }

    public PasseioBicicleta(int id, String name) {
        super(id, name);
    }
    
    public void addLocal(String local){
        locals.add(local);
        rrr.add("idc" + local);
    }

    public ArrayList<String> locais(){
        if (s_list != null){
            for (String s : s_list){
                locals.add(s);
                rrr.add("idc" + s);
            }
            return locals;
        }
        else
        {
            return locals;
        }
    }

}
