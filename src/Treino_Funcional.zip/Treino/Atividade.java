package Treino;

public class Atividade {
    private int id;
    private String name;

    public Atividade(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNome(String nome) {
        this.name = nome;
    }
}
