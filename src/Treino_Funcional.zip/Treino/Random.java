package Treino;

import java.util.ArrayList;

public interface Random {
    public ArrayList<String> rrr = new ArrayList<String>();

}
