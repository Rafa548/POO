package Hmmmm;

abstract class Date {
    abstract void increment();
    abstract void decrement();
}
