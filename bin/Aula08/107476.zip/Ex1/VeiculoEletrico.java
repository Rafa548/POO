package Aula08.Ex1;

public interface VeiculoEletrico {
    int autonomia();
    void carregar(int percentagem);
}
